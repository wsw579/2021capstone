package com.example.capstone.adapter;

public class INTENT_PATH {
}
