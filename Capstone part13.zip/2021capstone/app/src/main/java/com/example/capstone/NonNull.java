package com.example.capstone;

public @interface NonNull {
}
